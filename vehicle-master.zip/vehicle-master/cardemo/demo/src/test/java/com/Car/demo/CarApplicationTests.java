package com.Car.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarApplicationTests {

	@Test
	void contextLoads() {
	}

}
